"""
Build the Week 5 drive graph in ONE run — no manual node dragging.

Run this in Isaac Sim: Window > Script Editor, paste, press the run button
(or Ctrl+Enter). It adds the drive nodes to the EXISTING /World/ActionGraph
(the one already publishing your camera) without touching the camera nodes.

Creates and wires:
  ROS2 Subscribe Twist (/cmd_vel)
    -> Break linear velocity  -> Differential Controller (linear)
    -> Break angular velocity -> Differential Controller (angular)
  Differential Controller -> Articulation Controller -> robot joints

After it runs with no errors, SAVE (Ctrl+S) immediately.
"""

import omni.graph.core as og

GRAPH_PATH = "/World/ActionGraph"
ROBOT_PATH = "/World/carter_v1"

# wheel params — Carter v1 standard; adjust if the robot drives curved
WHEEL_RADIUS = 0.24
WHEEL_DISTANCE = 0.54
MAX_LINEAR = 1.0
MAX_ANGULAR = 1.5

keys = og.Controller.Keys
og.Controller.edit(
    GRAPH_PATH,
    {
        keys.CREATE_NODES: [
            ("SubscribeTwist", "isaacsim.ros2.bridge.ROS2SubscribeTwist"),
            ("BreakLinear", "omni.graph.nodes.BreakVector3"),
            ("BreakAngular", "omni.graph.nodes.BreakVector3"),
            ("DiffController", "isaacsim.robot.wheeled_robots.DifferentialController"),
            ("ArticController", "isaacsim.core.nodes.IsaacArticulationController"),
        ],
        keys.SET_VALUES: [
            ("SubscribeTwist.inputs:topicName", "/cmd_vel"),
            ("DiffController.inputs:wheelRadius", WHEEL_RADIUS),
            ("DiffController.inputs:wheelDistance", WHEEL_DISTANCE),
            ("DiffController.inputs:maxLinearSpeed", MAX_LINEAR),
            ("DiffController.inputs:maxAngularSpeed", MAX_ANGULAR),
            ("ArticController.inputs:targetPrim", ROBOT_PATH),
        ],
        keys.CONNECT: [
            # drive the whole chain off the existing playback tick
            ("on_playback_tick.outputs:tick", "SubscribeTwist.inputs:execIn"),
            ("SubscribeTwist.outputs:execOut", "DiffController.inputs:execIn"),
            ("DiffController.outputs:execOut", "ArticController.inputs:execIn"),
            # linear velocity vector -> break -> x component
            ("SubscribeTwist.outputs:linearVelocity", "BreakLinear.inputs:tuple"),
            ("BreakLinear.outputs:x", "DiffController.inputs:linearVelocity"),
            # angular velocity vector -> break -> z component
            ("SubscribeTwist.outputs:angularVelocity", "BreakAngular.inputs:tuple"),
            ("BreakAngular.outputs:z", "DiffController.inputs:angularVelocity"),
            # differential output -> articulation controller
            ("DiffController.outputs:velocityCommand", "ArticController.inputs:velocityCommand"),
        ],
    },
)

print("Drive graph built. If no errors above, SAVE NOW (Ctrl+S).")
