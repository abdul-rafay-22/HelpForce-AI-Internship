#!/usr/bin/env python3
"""
perception_bridge_node.py — Week 5, Checklist Phase 1 + Phase 3

Turns your Week 4 detect_row.py logic (HSV mask + column-histogram peak
selection) into a LIVE ROS2 node: subscribes to the camera feed every
frame, publishes a row-offset signal the controller can consume.

Topics:
  Subscribes: /robot/camera/image_raw   (sensor_msgs/Image)
  Publishes:
    /perception/row_offset    (std_msgs/Float32) — pixel offset from image
                                center; positive = detected row is to the
                                RIGHT of center.
    /perception/row_detected  (std_msgs/Bool) — True only on frames where
                                a usable row peak was found. The controller
                                uses this for its safety stop, not silence.
    /perception/debug_image   (sensor_msgs/Image) — mask with the picked
                                peak drawn on it, so you can eyeball
                                whether it's tracking the actual row or
                                garbage before you trust it with control.
                                View with: ros2 run rqt_image_view rqt_image_view

Run standalone for testing:
  python3 perception_bridge_node.py
  (normally started together with the controller via run_week5_pipeline.sh)
"""

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float32, Bool
from cv_bridge import CvBridge


def find_peaks_simple(values, min_height, min_distance):
    """Minimal local-maxima finder (no scipy dependency). Returns column
    indices that are local maxima, at least min_distance apart, above
    min_height. If two peaks are closer than min_distance, keeps the
    taller one."""
    peaks = []
    for i in range(1, len(values) - 1):
        if values[i] < min_height:
            continue
        if values[i] >= values[i - 1] and values[i] >= values[i + 1]:
            if not peaks or (i - peaks[-1]) >= min_distance:
                peaks.append(i)
            elif values[i] > values[peaks[-1]]:
                peaks[-1] = i
    return peaks


class PerceptionBridgeNode(Node):
    def __init__(self):
        super().__init__('perception_bridge_node')

        # Starting point = your Week 3/4 calibrated HSV values (green
        # vegetation hue 47-61, soil hue 0-25). Widened slightly here for
        # robustness margin — retune against your Week 5 field's actual
        # rendered frames if detection looks off.
        self.declare_parameter('hue_low', 42)
        self.declare_parameter('hue_high', 66)
        self.declare_parameter('sat_min', 40)
        self.declare_parameter('val_min', 40)
        self.declare_parameter('min_peak_height_frac', 0.15)  # fraction of image height
        self.declare_parameter('min_peak_distance_px', 40)
        self.declare_parameter('smoothing_kernel', 9)
        self.declare_parameter('image_topic', '/robot/camera/image_raw')
        self.declare_parameter('publish_debug_image', True)

        self.hue_low = self.get_parameter('hue_low').value
        self.hue_high = self.get_parameter('hue_high').value
        self.sat_min = self.get_parameter('sat_min').value
        self.val_min = self.get_parameter('val_min').value
        self.min_peak_height_frac = self.get_parameter('min_peak_height_frac').value
        self.min_peak_distance_px = self.get_parameter('min_peak_distance_px').value
        self.smoothing_kernel = self.get_parameter('smoothing_kernel').value
        self.publish_debug = self.get_parameter('publish_debug_image').value

        image_topic = self.get_parameter('image_topic').value

        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, image_topic, self.image_callback, 10)
        self.offset_pub = self.create_publisher(Float32, '/perception/row_offset', 10)
        self.detected_pub = self.create_publisher(Bool, '/perception/row_detected', 10)
        if self.publish_debug:
            self.debug_pub = self.create_publisher(Image, '/perception/debug_image', 10)

        self.get_logger().info(f'PerceptionBridgeNode up, listening on {image_topic}')

    def image_callback(self, msg: Image):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        h, w = frame.shape[:2]
        center_col = w / 2.0

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower = np.array([self.hue_low, self.sat_min, self.val_min])
        upper = np.array([self.hue_high, 255, 255])
        mask = cv2.inRange(hsv, lower, upper)

        col_sums = np.sum(mask > 0, axis=0).astype(np.float32)
        k = max(1, int(self.smoothing_kernel))
        kernel = np.ones(k, dtype=np.float32) / k
        smoothed = np.convolve(col_sums, kernel, mode='same')

        min_height = self.min_peak_height_frac * h
        peaks = find_peaks_simple(smoothed, min_height, self.min_peak_distance_px)

        detected_msg = Bool()
        offset_msg = Float32()
        best_peak = None

        if peaks:
            best_peak = min(peaks, key=lambda c: abs(c - center_col))
            offset_msg.data = float(best_peak - center_col)
            detected_msg.data = True
        else:
            offset_msg.data = 0.0
            detected_msg.data = False

        self.offset_pub.publish(offset_msg)
        self.detected_pub.publish(detected_msg)

        if self.publish_debug:
            debug = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
            cv2.line(debug, (int(center_col), 0), (int(center_col), h), (0, 0, 255), 1)
            if best_peak is not None:
                cv2.line(debug, (int(best_peak), 0), (int(best_peak), h), (0, 255, 0), 2)
            debug_msg = self.bridge.cv2_to_imgmsg(debug, encoding='bgr8')
            debug_msg.header = msg.header
            self.debug_pub.publish(debug_msg)


def main(args=None):
    rclpy.init(args=args)
    node = PerceptionBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
