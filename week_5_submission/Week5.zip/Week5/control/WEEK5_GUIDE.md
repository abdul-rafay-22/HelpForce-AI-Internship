# Week 5 Guide — Control & Autonomous Row-Following

Straight rows confirmed → controller choice is **PID**, not pure pursuit.
Pure pursuit's only real advantage over PID is tracking curvature via a
lookahead point — on a straight row there's no curvature to track, so it
adds tuning complexity (lookahead distance, wheelbase geometry mapping)
for no accuracy benefit. Write this reasoning into your tech notes
verbatim — it's exactly what checklist Phase 1 asks you to justify.

Files referenced below (all in this folder):
- `generate_week5_field.py` + `week5_field.usda` + `textures/` — the field (from earlier)
- `perception_bridge_node.py` — live row detection → ROS2 topics
- `row_follower_controller.py` — PID controller → `/cmd_vel`
- `test_logger_node.py` — per-run closed-loop logging, auto success/fail
- `analyze_results.py` — summarizes results CSVs into your before/after numbers
- `run_week5_pipeline.sh` — one command to start perception + control together

---

## Part A — Import the field into Isaac Sim

1. Copy `week5_field.usda` AND its `textures/` folder together into one
   place, e.g. `~/Documents/week5_field.usda` and `~/Documents/textures/`.
   They must stay next to each other — the leaf material references the
   texture by the path baked in when you ran the generator. If you moved
   the folder, just re-run `python3 generate_week5_field.py` from that
   new location so the paths bake in correctly again.
2. Open Isaac Sim 6.0.1.
3. Open your existing Week 4 stage (the one with Carter v1 and the camera
   Action Graph already set up) — do not start from a blank stage.
4. In the Content Browser, navigate to where you copied `week5_field.usda`.
5. **Drag it into the viewport** to add it as a reference under your
   existing stage — the same drag-and-drop method you used for Carter v1.
   Do NOT double-click it open; that replaces your whole stage.
6. Select the robot prim and set its Translate values so it starts at the
   entrance of whichever row you want to test first. Row X positions for
   this field (6 rows, 1.8m spacing, centered on X=0): row 0 = -4.5,
   row 1 = -2.7, row 2 = -0.9, row 3 = 0.9, row 4 = 2.7, row 5 = 4.5.
   Row runs from Y = -7.0 (entrance) to Y = +7.0 (end).
7. Press Play once and watch the frame rate counter (top of viewport).
   If it's noticeably worse than your Week 4 baseline, that's the
   density/performance tradeoff from earlier catching up — first thing
   to try is lowering `PLANT_SPACING` in `generate_week5_field.py` back
   toward 1.2 and regenerating, before touching anything else.
8. Save the stage.

---

## Part B — Checklist Phase 1: confirm perception is actually usable

Don't skip this — it's the brief's own first requirement, and it's a
real gate, not paperwork. If the signal is bad here, everything you
build on top of it will be bad too.

1. Install two packages if you don't already have them:
   ```
   sudo apt install ros-jazzy-cv-bridge ros-jazzy-vision-opencv
   pip install opencv-python numpy --break-system-packages
   ```
2. With the sim running and the robot's camera Action Graph active,
   confirm the camera is actually publishing:
   ```
   ros2 topic hz /robot/camera/image_raw
   ```
   You should see a steady rate. If nothing prints, the camera
   Action Graph isn't wired the way it was in Week 4 — fix that before
   going further; there's nothing for the perception bridge to read.
3. Run the perception bridge on its own:
   ```
   cd week5_code
   python3 perception_bridge_node.py
   ```
4. In another terminal, watch the offset numbers:
   ```
   ros2 topic echo /perception/row_offset
   ```
5. In a third terminal, view the debug mask so you can see with your own
   eyes what it's tracking:
   ```
   ros2 run rqt_image_view rqt_image_view
   ```
   Pick `/perception/debug_image`. You should see a white blob where the
   row is, a red line at image center, and a green line at the detected
   peak. If the green line is sitting on soil or jumping between rows,
   the HSV parameters need retuning — adjust `hue_low`/`hue_high` on the
   command line and re-run, e.g.:
   ```
   python3 perception_bridge_node.py --ros-args -p hue_low:=38 -p hue_high:=70
   ```
6. Manually nudge the robot to a few different lateral offsets (including
   your worst-case drift, since that's exactly where Week 4 showed the
   highest error) and confirm the offset sign and rough magnitude make
   sense at each one. Note in your tech notes whether detection held up
   at max drift or not — this is your Phase 1 "flag blocking dependencies"
   answer either way.

---

## Part C — Checklist Phase 2: implement the controller

`row_follower_controller.py` is ready to go. What it does, in plain words:

- Reads the row offset and a "did we actually detect a row this frame"
  flag separately — it does NOT guess based on message timing alone.
- Smooths the raw offset with a simple exponential filter before using
  it (`offset_filter_alpha`, default 0.3) — this directly targets the
  Week 4 finding that error was worst at maximum drift, by not letting
  a single noisy frame yank the derivative term around.
- Runs PD control: `angular_z = -(kp * error + kd * derivative)`,
  constant forward speed.
- Publishes zero velocity (stop) if no valid detection for
  `max_missed_ticks` consecutive control ticks — that's the safety logic
  checklist Phase 2 asks for.

Nothing to write here — just review the file so you can speak to it in
your tech notes and adjust parameters later during tuning.

---

## Part D — Checklist Phase 2 (continued): map controller output to wheels

Your Week 3/4 setup uses Action Graph for robot control (the fallback
your own notes call out, since `omni.isaac.core` isn't reliably available
in your build). Wire it there, in the same graph your camera publishing
already lives in:

Node list and exact connections (all live in the SAME Action Graph your
camera publishing already uses — don't create a second graph):

1. **On Playback Tick** — the trigger. Feeds every other node's exec
   input, every frame.
2. **ROS2 Subscribe Twist** — set topic to `/cmd_vel`. Exec input ← Tick.
   Outputs `linearVelocity` and `angularVelocity` (3D vectors).
3. **Differential Controller** — exec input ← Subscribe Twist's exec
   output. Feed its `linearVelocity`/`angularVelocity` inputs from step 2's
   outputs. If it rejects a direct vector connection (some Isaac Sim
   versions want scalars here), add a **Break 3 Vector** node on each
   output first and feed it the X component (linear) and Z component
   (angular) instead — check the input's own tooltip before assuming you
   need this. Set `wheelRadius` and `wheelDistance` as constants: don't
   guess these — select the robot's wheel joints in the Stage/Property
   panel and read the actual physical dimensions off the prim. Wrong
   values here silently produce wrong turning behavior that looks like a
   bad PID tune when it isn't. Outputs one array of left/right wheel
   velocities.
4. **Articulation Controller** — exec input ← Differential Controller's
   exec output. `targetPrim` = the robot's articulation root.
   `jointNames` = your two wheel joint names, in the same left-then-right
   order the Differential Controller outputs them in — a mismatch here
   makes the robot spin instead of drive straight. Feed it the velocity
   array from step 3.

That's the whole control chain: Tick → Subscribe Twist → Differential
Controller → Articulation Controller → wheel joints.

For the odometry publisher you'll need in Part E, in the same graph:

5. **Isaac Compute Odometry** — exec input ← Tick. `chassisPrim` = the
   robot's base/chassis prim.
6. **ROS2 Publish Odometry** — exec input ← Compute Odometry's exec
   output. Topic `/odom`, fed from Compute Odometry's position/orientation/
   velocity outputs.

Test the control chain in isolation before bringing perception into it at all:
   ```
   ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.2}, angular: {z: 0.0}}"
   ```
   Confirm the robot drives straight forward in the viewport. Then try a
   nonzero `angular.z` and confirm it turns the right direction — if it
   turns backwards from what you expect, flip the sign on `angular_z` in
   `row_follower_controller.py` rather than fighting it in Action Graph.

---

## Part E — Checklist Phase 3: ROS2 integration end-to-end

1. You likely also need an odometry publisher for later testing — check
   if one exists from earlier weeks:
   ```
   ros2 topic list | grep odom
   ```
   If nothing shows up, add **Isaac Compute Odometry** → **ROS2 Publish
   Odometry** nodes to the same Action Graph, targeting the robot's
   articulation root, topic `/odom`, frame `odom`. The closed-loop test
   logger in Part F needs this.
2. Make the pipeline script executable and run both nodes together:
   ```
   chmod +x run_week5_pipeline.sh
   ./run_week5_pipeline.sh
   ```
3. With the sim playing and the robot placed at a row entrance, confirm:
   ```
   ros2 topic hz /perception/row_offset
   ros2 topic hz /cmd_vel
   ```
   Both rates should be steady and close to what you configured
   (`control_rate_hz`, default 20Hz for the controller; the perception
   rate follows your camera's publish rate). If `/cmd_vel` is visibly
   lagging behind `/perception/row_offset`, that's the checklist's "control
   loop doesn't lag behind perception" requirement failing — check your
   sim FPS first (Part A step 7), since a dense field is the most likely
   cause given today's changes.
4. Watch the robot attempt to follow the row. It won't be tuned yet —
   that's expected. You're confirming the whole chain is connected, not
   that it's good yet.

---

## Part F — Checklist Phase 4: closed-loop testing

Run at least 3-5 starting offsets per row (e.g. centered, +0.2m, -0.2m,
+drift-max, -drift-max). For each one:

1. Stop the sim, manually set the robot's Translate X to
   `<row_centerline_x> + <your test offset>`, Y to -7.0 (row entrance).
   Press Play.
2. Start the pipeline if it isn't already running:
   ```
   ./run_week5_pipeline.sh
   ```
3. In another terminal, start the logger for this one run (example for
   row 2, centerline X = -0.9, testing +0.2m offset):
   ```
   python3 test_logger_node.py --ros-args \
     -p row_centerline_x:=-0.9 \
     -p row_end_y:=7.0 \
     -p fail_deviation_m:=0.6 \
     -p timeout_sec:=60.0 \
     -p run_label:=baseline_row2_offset_p0.2 \
     -p results_csv:=week5_results_baseline.csv
   ```
4. Let it run — the logger exits on its own once the robot reaches the
   end of the row (SUCCESS), leaves the row (FAIL_LEFT_ROW), or times out
   (FAIL_TIMEOUT). It appends one line to `week5_results_baseline.csv`
   and writes a full per-tick trace to `week5_run_logs/<run_label>.csv`.
5. Reset the robot to the next offset and repeat, same `results_csv` file
   each time so they all land in one place.
6. Once you've done all your baseline runs:
   ```
   python3 analyze_results.py week5_results_baseline.csv
   ```
   This prints your baseline success rate and deviation numbers —
   straight into your tech notes.

---

## Part G — Checklist Phase 5: tuning

Read the per-tick logs and the `analyze_results.py` output to diagnose,
then adjust:

- **Oscillating side to side, overshooting the centerline** → `kd` too
  low relative to `kp`, or `kp` itself too high. Lower `kp` first, then
  raise `kd` slightly.
- **Sluggish, drifts before correcting, doesn't recover from large
  offsets** → `kp` too low. Raise it.
- **Jittery even on a straight approach** → the offset filter isn't
  smoothing enough. Lower `offset_filter_alpha` (e.g. 0.3 → 0.2).
- **Fails specifically at your max-drift starting offset but not at
  smaller ones** → this is the Week 4 detection-reliability issue showing
  up in control. Lower `offset_filter_alpha` further before touching gains.

Run the controller standalone with new gains to test one change at a time:
```
python3 row_follower_controller.py --ros-args -p kp:=0.03 -p kd:=0.015
```
Once you're happy, re-run the SAME set of starting offsets from Part F
into a new results file:
```
python3 test_logger_node.py --ros-args \
  -p row_centerline_x:=-0.9 -p row_end_y:=7.0 -p fail_deviation_m:=0.6 \
  -p timeout_sec:=60.0 -p run_label:=tuned_row2_offset_p0.2 \
  -p results_csv:=week5_results_tuned.csv
```
Then:
```
python3 analyze_results.py week5_results_baseline.csv week5_results_tuned.csv
```
Two blocks of output side by side — that's your before/after table.

---

## Part H — Recording

Use Isaac Sim's built-in Movie Capture extension (Window → Movie Capture)
or a plain screen recorder (OBS on Ubuntu) to capture ONE full successful
run end-to-end — robot enters the row, follows it, reaches the end. Since
this might end up on LinkedIn: frame the camera to show the robot and the
row clearly, and use one of your tuned (post-Phase-5) runs, not a
baseline one — no reason to show your worst result when you have a better
one on hand.

---

## Part I — Checklist Phase 6: technical notes

Write a short doc (mentor-facing, plain language) covering exactly these,
matching the checklist's Final Deliverables table 1:1:

1. **Control approach chosen and why** — PID, straight rows, pure pursuit's
   curvature-tracking advantage doesn't apply (Part above already gives
   you this paragraph almost verbatim).
2. **ROS2 integration and safety logic** — topic list (`/robot/camera/image_raw`
   → `/perception/row_offset` + `/perception/row_detected` → `/cmd_vel`
   → Action Graph → wheels), and the missed-detection stop behavior.
3. **Closed-loop results before and after tuning** — paste the
   `analyze_results.py` output for both CSVs.
4. **Known issues / limitations** — be specific: e.g. detection accuracy
   at maximum lateral drift, mitigated but not eliminated by offset
   smoothing; any starting offsets that still failed after tuning; frame
   rate impact from the denser Week 5 field if you saw one.

## Final deliverables checklist (nothing left out)

| # | Deliverable | Where it comes from |
|---|---|---|
| 1 | Controller implemented | `row_follower_controller.py` |
| 2 | ROS2 integration | Parts D + E |
| 3 | Full row completed autonomously | Part F, at least one SUCCESS run |
| 4 | Logged deviation + success rate | `week5_results_*.csv` + `analyze_results.py` output |
| 5 | Screen recording | Part H |
| 6 | Technical notes | Part I |
