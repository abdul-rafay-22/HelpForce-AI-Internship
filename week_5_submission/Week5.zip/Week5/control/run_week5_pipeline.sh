#!/bin/bash
# run_week5_pipeline.sh — Week 5 deployment
#
# Starts the perception bridge and the row-follower controller together.
# No ROS2 package / colcon build needed — runs the raw scripts directly,
# same style as your existing detect_row.py workflow.
#
# Usage:
#   chmod +x run_week5_pipeline.sh
#   ./run_week5_pipeline.sh
#
# To override gains for tuning, don't edit this file — run the controller
# by itself instead (see the guide's Phase 5 section), or edit the two
# `python3 ... &` lines below to add --ros-args -p kp:=0.03 etc.
#
# Ctrl+C stops both nodes.

set -e

python3 perception_bridge_node.py &
PERCEPTION_PID=$!

python3 row_follower_controller.py &
CONTROLLER_PID=$!

trap "echo 'Stopping...'; kill $PERCEPTION_PID $CONTROLLER_PID 2>/dev/null" SIGINT SIGTERM

wait
