#!/usr/bin/env python3
"""
perception_debug_snapshot.py — one-shot detection diagnostic

Grabs ONE frame from the camera, runs the exact same HSV + column-histogram
detection as perception_bridge_node.py, and saves annotated images to disk
so you can see what detection is actually locking onto. No rqt, no debug
topic, no cv_bridge encoding bug — writes PNGs you open normally.

Saves to ./perception_debug/:
  raw.png       — what the camera sees
  mask.png      — the green (vegetation) mask
  overlay.png   — mask + red center line + green detected-peak line +
                  the column histogram drawn along the bottom

Run (with Isaac on Play, camera publishing):
  source /opt/ros/jazzy/setup.bash
  python3 perception_debug_snapshot.py

It grabs one frame, prints the offset, saves the images, and exits.
"""

import os

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge


def find_peaks_simple(values, min_height, min_distance):
    peaks = []
    for i in range(1, len(values) - 1):
        if values[i] < min_height:
            continue
        if values[i] >= values[i - 1] and values[i] >= values[i + 1]:
            if not peaks or (i - peaks[-1]) >= min_distance:
                peaks.append(i)
            elif values[i] > values[peaks[-1]]:
                peaks[-1] = i
    return peaks


class SnapshotNode(Node):
    def __init__(self):
        super().__init__('perception_debug_snapshot')
        self.bridge = CvBridge()
        self.done = False
        self.sub = self.create_subscription(
            Image, '/robot/camera/image_raw', self.cb, 10)
        self.get_logger().info('Waiting for one camera frame...')

    def cb(self, msg):
        if self.done:
            return
        self.done = True

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        h, w = frame.shape[:2]
        center_col = w / 2.0

        # same detection as the live node
        hue_low, hue_high, sat_min, val_min = 42, 66, 40, 40
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower = np.array([hue_low, sat_min, val_min])
        upper = np.array([hue_high, 255, 255])
        mask = cv2.inRange(hsv, lower, upper)

        col_sums = np.sum(mask > 0, axis=0).astype(np.float32)
        k = 9
        kernel = np.ones(k, dtype=np.float32) / k
        smoothed = np.convolve(col_sums, kernel, mode='same')

        min_height = 0.15 * h
        peaks = find_peaks_simple(smoothed, min_height, 40)

        best_peak = None
        if peaks:
            best_peak = min(peaks, key=lambda c: abs(c - center_col))
            offset = best_peak - center_col
        else:
            offset = 0.0

        out_dir = 'perception_debug'
        os.makedirs(out_dir, exist_ok=True)

        cv2.imwrite(os.path.join(out_dir, 'raw.png'), frame)
        cv2.imwrite(os.path.join(out_dir, 'mask.png'), mask)

        overlay = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        cv2.line(overlay, (int(center_col), 0), (int(center_col), h), (0, 0, 255), 2)
        for p in peaks:
            color = (0, 255, 0) if p == best_peak else (0, 165, 255)
            cv2.line(overlay, (int(p), 0), (int(p), h), color, 2)

        # draw the histogram along the bottom so you can see every peak
        if smoothed.max() > 0:
            norm = (smoothed / smoothed.max() * (h * 0.3)).astype(int)
            for x in range(w):
                cv2.line(overlay, (x, h - 1), (x, h - 1 - int(norm[x])), (255, 255, 0), 1)

        cv2.imwrite(os.path.join(out_dir, 'overlay.png'), overlay)

        print('\n=== detection snapshot ===')
        print(f'image size: {w} x {h}, center column = {center_col:.0f}')
        print(f'peaks found at columns: {peaks}')
        print(f'chosen peak (nearest center): {best_peak}')
        print(f'row_offset = {offset:.1f} px  (positive = row right of center)')
        print(f'saved images to ./{out_dir}/  — open overlay.png first')
        rclpy.shutdown()


def main():
    rclpy.init()
    node = SnapshotNode()
    rclpy.spin(node)


if __name__ == '__main__':
    main()
