#!/usr/bin/env python3
"""
row_follower_controller.py — Week 5, Checklist Phase 1b + Phase 2 + Phase 3

PD row-following controller (straight rows -> PID beats pure pursuit here;
pure pursuit's whole value is curvature tracking via a lookahead point,
which a straight row doesn't need). Subscribes to the perception bridge's
offset + detected signals, publishes /cmd_vel on its own fixed-rate timer
(decoupled from the camera's frame rate, so control stays smooth even if
perception briefly stutters).

Includes two things the checklist explicitly asks for:
  1. Safety stop — if no valid detection for `max_missed_ticks` consecutive
     control ticks, publish zero velocity instead of guessing.
  2. Exponential smoothing on the offset signal (`offset_filter_alpha`) —
     your Week 4 perception had its worst error concentrated at maximum
     lateral drift; smoothing the raw offset before it drives the
     controller directly addresses that instead of feeding noise straight
     into the derivative term (which would amplify it).

Topics:
  Subscribes: /perception/row_offset, /perception/row_detected
  Publishes:  /cmd_vel (geometry_msgs/Twist)

Run standalone for testing:
  python3 row_follower_controller.py
Override gains at the command line:
  python3 row_follower_controller.py --ros-args -p kp:=0.03 -p kd:=0.015
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, Bool
from geometry_msgs.msg import Twist


class RowFollowerController(Node):
    def __init__(self):
        super().__init__('row_follower_controller')

        self.declare_parameter('kp', 0.02)
        self.declare_parameter('kd', 0.01)
        self.declare_parameter('linear_speed', 0.4)
        self.declare_parameter('control_rate_hz', 20.0)
        self.declare_parameter('max_missed_ticks', 10)  # ~0.5s at 20Hz
        self.declare_parameter('offset_filter_alpha', 0.3)  # 0=heavy smoothing, 1=no smoothing
        self.declare_parameter('offset_topic', '/perception/row_offset')
        self.declare_parameter('detected_topic', '/perception/row_detected')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        self.kp = self.get_parameter('kp').value
        self.kd = self.get_parameter('kd').value
        self.linear_speed = self.get_parameter('linear_speed').value
        self.max_missed_ticks = self.get_parameter('max_missed_ticks').value
        self.filter_alpha = self.get_parameter('offset_filter_alpha').value
        rate_hz = self.get_parameter('control_rate_hz').value

        self.prev_error = 0.0
        self.prev_time = self.get_clock().now()
        self.filtered_offset = 0.0
        self.last_detected = False
        self.missed_ticks = 0

        self.offset_sub = self.create_subscription(
            Float32, self.get_parameter('offset_topic').value, self.offset_cb, 10)
        self.detected_sub = self.create_subscription(
            Bool, self.get_parameter('detected_topic').value, self.detected_cb, 10)
        self.cmd_pub = self.create_publisher(
            Twist, self.get_parameter('cmd_vel_topic').value, 10)
        self.timer = self.create_timer(1.0 / rate_hz, self.control_loop)

        self.get_logger().info(
            f'RowFollowerController up. kp={self.kp} kd={self.kd} '
            f'linear_speed={self.linear_speed} rate={rate_hz}Hz '
            f'offset_filter_alpha={self.filter_alpha}'
        )

    def offset_cb(self, msg: Float32):
        a = self.filter_alpha
        self.filtered_offset = a * msg.data + (1.0 - a) * self.filtered_offset

    def detected_cb(self, msg: Bool):
        self.last_detected = msg.data
        if msg.data:
            self.missed_ticks = 0

    def control_loop(self):
        now = self.get_clock().now()
        dt = (now - self.prev_time).nanoseconds / 1e9
        self.prev_time = now
        if dt <= 0.0:
            dt = 1e-3

        cmd = Twist()

        if not self.last_detected:
            self.missed_ticks += 1

        if self.missed_ticks > self.max_missed_ticks:
            self.get_logger().warn(
                f'Row lost for {self.missed_ticks} ticks — stopping.',
                throttle_duration_sec=1.0,
            )
            self.cmd_pub.publish(cmd)  # zero Twist = stop
            return

        error = self.filtered_offset
        derivative = (error - self.prev_error) / dt
        angular_z = -(self.kp * error + self.kd * derivative)
        self.prev_error = error

        cmd.linear.x = self.linear_speed
        cmd.angular.z = angular_z
        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = RowFollowerController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
