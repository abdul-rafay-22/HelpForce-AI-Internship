# Isaac Sim recovery snippet — Week 5
# Run this in Isaac Sim's Script Editor (Window > Script Editor) to restore
# the robot position + camera pitch to the known-good values, in case of a
# crash. Adjust the numbers if you fine-tune later.
#
# NOTE: this only restores robot placement + camera angle. It does NOT
# rebuild the Action Graph drive nodes — save the stage (Ctrl+S) to keep
# those.

import omni.usd
from pxr import Gf, UsdGeom

stage = omni.usd.get_context().get_stage()

# --- robot position (known-good lane placement) ---
robot = stage.GetPrimAtPath("/World/carter_v1")
xform = UsdGeom.Xformable(robot)
# clear existing transform ops to avoid stacking
xform.ClearXformOpOrder()
xform.AddTranslateOp().Set(Gf.Vec3d(1.8, 0.6, 0.3))
# heading: adjust the Z rotation (degrees) until nose points down the lane
xform.AddRotateXYZOp().Set(Gf.Vec3f(0.0, 0.0, 0.0))

# --- camera pitch (known-good: sees ground + rows) ---
cam = stage.GetPrimAtPath(
    "/World/carter_v1/chassis_link/camera_mount/carter_camera_first_person")
cam_xform = UsdGeom.Xformable(cam)
cam_xform.ClearXformOpOrder()
cam_xform.AddTranslateOp().Set(Gf.Vec3d(0.08917, 0.0, 0.3265))
cam_xform.AddRotateXYZOp().Set(Gf.Vec3f(90.0, 250.0, 0.0))

print("Recovery applied: robot + camera set to known-good values.")
