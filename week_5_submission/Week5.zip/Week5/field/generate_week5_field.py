#!/usr/bin/env python3
"""
Week 5 Field Generator — Agriculture Row-Following (Isaac Sim)

Extends the Week 4 field: 6 rows, denser plant spacing, richer plant
geometry (stem + multi-cluster leaves + palette variation), per-face soil
color variation, furrow ridges. Ground-only collision — no per-plant
colliders — because a denser field is a real risk to your control-loop
tick rate on an RTX 3050, and the Week 5 checklist explicitly requires the
control loop not lag behind perception updates.

Requires: pip install usd-core pillow
Run:      python3 generate_week5_field.py
Output:   week5_field.usd  +  textures/leaf_diffuse.png (generated locally,
           no download — a leaf-shaped alpha-cutout texture reused by all
           four plant palettes via per-material tint, so texture memory
           cost stays at one file, not four)

Keep the textures/ folder next to week5_field.usd when you move it —
the shaders reference it by absolute path baked in at generation time.

Import into Isaac Sim the same way you handled Carter v1 in Week 4 —
reference/drag-drop it into your stage, don't just double-click-open it
over your existing scene.
"""

import math
import os
import random

from pxr import Usd, UsdGeom, UsdShade, UsdPhysics, Gf, Sdf
from PIL import Image, ImageDraw

# ---------------------------------------------------------------------------
# CONFIG — tune here
# ---------------------------------------------------------------------------
OUTPUT_PATH = "week5_field.usd"

NUM_ROWS = 6            # was 5 in Week 4
ROW_SPACING = 1.8       # m — unchanged from Week 3/4. Do NOT change this one:
                         # your Week 4 perception calibration (HSV + column
                         # histogram) was tuned against this spacing.
PLANT_SPACING = 0.25    # very dense — plants nearly touch = continuous green row for stable detection
ROW_LENGTH = 14.0       # m — longer row to fit more plants at tighter spacing
FIELD_MARGIN = 2.0      # m of bare ground around the crop rows

JITTER_XY = 0.08        # m, per-plant lateral/longitudinal jitter
JITTER_ROT_DEG = 15.0   # degrees, random yaw per plant
JITTER_SCALE = (0.5, 0.7)

FURROW_WIDTH = 0.25
FURROW_HEIGHT = 0.04
FURROW_COLOR = Gf.Vec3f(0.38, 0.27, 0.16)  # darker tan, tilled-ridge look

SOIL_BASE_COLORS = [
    Gf.Vec3f(0.55, 0.42, 0.25),   # tan tilled soil
    Gf.Vec3f(0.48, 0.36, 0.20),   # damp tilled soil
    Gf.Vec3f(0.60, 0.47, 0.30),   # sun-bleached tan soil
]

# 4 crop prototypes with distinct palettes so the field doesn't read as one
# green blob repeated — mixed maturity/condition is what makes it look real.
PLANT_PALETTES = [
    {"name": "CropA_Mature", "leaf": Gf.Vec3f(0.13, 0.42, 0.11), "stem": Gf.Vec3f(0.25, 0.35, 0.10)},
    {"name": "CropB_Young", "leaf": Gf.Vec3f(0.24, 0.55, 0.18), "stem": Gf.Vec3f(0.30, 0.45, 0.15)},
    {"name": "CropC_Flowering", "leaf": Gf.Vec3f(0.16, 0.38, 0.13), "stem": Gf.Vec3f(0.22, 0.32, 0.11),
     "accent": Gf.Vec3f(0.92, 0.90, 0.80)},
    {"name": "CropD_Stressed", "leaf": Gf.Vec3f(0.45, 0.42, 0.14), "stem": Gf.Vec3f(0.35, 0.30, 0.12)},
]

TEXTURE_DIR = "textures"
LEAF_TEXTURE_NAME = "leaf_diffuse.png"
LEAF_TEXTURE_BASE_COLOR = (90, 150, 60)  # RGB the palette tints are scaled against

random.seed(42)  # reproducible layout — change the seed for a fresh field


def generate_leaf_texture(path, size=256):
    """Procedural leaf-shaped texture with alpha cutout, veins, and light
    per-pixel noise. Generated locally — no download, no external asset
    dependency, single small file reused by every leaf on every plant."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    cx, cy = size / 2, size / 2
    rx, ry = size * 0.42, size * 0.46

    pts = []
    for i in range(64):
        t = i / 64 * 2 * math.pi
        pinch = 1.0 - 0.35 * abs(math.cos(t)) ** 3  # tapers to a point top/bottom
        pts.append((cx + rx * pinch * math.cos(t), cy + ry * pinch * math.sin(t)))
    draw.polygon(pts, fill=LEAF_TEXTURE_BASE_COLOR + (255,))

    vein_color = (60, 110, 40, 200)
    draw.line([(cx, cy - ry * 0.9), (cx, cy + ry * 0.9)], fill=vein_color, width=3)
    for k in range(-3, 4):
        if k == 0:
            continue
        y0 = cy + k * ry * 0.22
        x1 = cx + rx * 0.6 * (1 if k % 2 == 0 else -1)
        draw.line([(cx, y0), (x1, y0 + ry * 0.12)], fill=vein_color, width=2)

    px = img.load()
    for _ in range(2000):
        x, y = random.randint(0, size - 1), random.randint(0, size - 1)
        r, g, b, a = px[x, y]
        if a > 0:
            j = random.randint(-15, 15)
            px[x, y] = (max(0, min(255, r + j)), max(0, min(255, g + j)), max(0, min(255, b + j)), a)

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    img.save(path)
    return path


def make_material(stage, path, color, roughness=0.85):
    mat = UsdShade.Material.Define(stage, path)
    shader = UsdShade.Shader.Define(stage, path + "/Shader")
    shader.CreateIdAttr("UsdPreviewSurface")
    shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(color)
    shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(roughness)
    shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.0)
    mat.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), "surface")
    return mat


def build_ground(stage, width, length):
    path = "/World/Ground"
    mesh = UsdGeom.Mesh.Define(stage, path)

    subdiv = 8  # 8x8 faces gives per-face soil variation without a heavy mesh
    step_x = width / subdiv
    step_y = length / subdiv

    pts, faces, counts = [], [], []
    for j in range(subdiv + 1):
        for i in range(subdiv + 1):
            pts.append(Gf.Vec3f(-width / 2 + i * step_x, 0.0, -length / 2 + j * step_y))
    for j in range(subdiv):
        for i in range(subdiv):
            a = j * (subdiv + 1) + i
            b = a + 1
            c = a + (subdiv + 1) + 1
            d = a + (subdiv + 1)
            faces += [a, b, c, d]
            counts.append(4)

    mesh.CreatePointsAttr(pts)
    mesh.CreateFaceVertexCountsAttr(counts)
    mesh.CreateFaceVertexIndicesAttr(faces)
    mesh.CreateExtentAttr([Gf.Vec3f(-width / 2, 0, -length / 2), Gf.Vec3f(width / 2, 0, length / 2)])

    color_primvar = mesh.CreateDisplayColorPrimvar("uniform")
    color_primvar.Set([random.choice(SOIL_BASE_COLORS) for _ in range(subdiv * subdiv)])

    # Ground collision only. Do not add colliders to plants — that's the
    # single biggest way a denser field kills your sim FPS and control loop
    # tick rate.
    UsdPhysics.CollisionAPI.Apply(mesh.GetPrim())
    return mesh


def build_furrows(stage, num_rows, row_spacing, row_length):
    furrow_mat = make_material(stage, "/World/Materials/Furrow", FURROW_COLOR)
    start_x = -((num_rows - 1) * row_spacing) / 2
    for r in range(num_rows):
        x = start_x + r * row_spacing
        box = UsdGeom.Cube.Define(stage, f"/World/Furrows/Furrow_{r}")
        box.CreateSizeAttr(1.0)
        xf = UsdGeom.Xformable(box)
        xf.AddScaleOp().Set(Gf.Vec3f(FURROW_WIDTH, FURROW_HEIGHT, row_length))
        xf.AddTranslateOp().Set(Gf.Vec3d(x, FURROW_HEIGHT / 2, 0.0))
        UsdShade.MaterialBindingAPI(box).Bind(furrow_mat)


def make_leaf_card_material(stage, path, texture_abs_path, leaf_color):
    """Textured, alpha-cutout leaf material. One shared texture file, tinted
    per palette via the texture shader's scale input — no per-palette
    texture files, so this doesn't multiply your texture memory cost by 4."""
    mat = UsdShade.Material.Define(stage, path)

    st_reader = UsdShade.Shader.Define(stage, path + "/StReader")
    st_reader.CreateIdAttr("UsdPrimvarReader_float2")
    st_reader.CreateInput("varname", Sdf.ValueTypeNames.Token).Set("st")
    st_out = st_reader.CreateOutput("result", Sdf.ValueTypeNames.Float2)

    base = Gf.Vec3f(*[c / 255.0 for c in LEAF_TEXTURE_BASE_COLOR])
    tint = Gf.Vec4f(leaf_color[0] / base[0], leaf_color[1] / base[1], leaf_color[2] / base[2], 1.0)

    tex = UsdShade.Shader.Define(stage, path + "/Texture")
    tex.CreateIdAttr("UsdUVTexture")
    tex.CreateInput("file", Sdf.ValueTypeNames.Asset).Set(texture_abs_path)
    tex.CreateInput("st", Sdf.ValueTypeNames.Float2).ConnectToSource(st_out)
    tex.CreateInput("scale", Sdf.ValueTypeNames.Float4).Set(tint)
    tex.CreateInput("wrapS", Sdf.ValueTypeNames.Token).Set("clamp")
    tex.CreateInput("wrapT", Sdf.ValueTypeNames.Token).Set("clamp")
    rgb_out = tex.CreateOutput("rgb", Sdf.ValueTypeNames.Float3)
    a_out = tex.CreateOutput("a", Sdf.ValueTypeNames.Float)

    surf = UsdShade.Shader.Define(stage, path + "/Surface")
    surf.CreateIdAttr("UsdPreviewSurface")
    surf.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(rgb_out)
    surf.CreateInput("opacity", Sdf.ValueTypeNames.Float).ConnectToSource(a_out)
    surf.CreateInput("opacityThreshold", Sdf.ValueTypeNames.Float).Set(0.3)  # cutout, not blend — cheaper
    surf.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(0.75)
    mat.CreateSurfaceOutput().ConnectToSource(surf.ConnectableAPI(), "surface")
    return mat


def add_leaf_card(stage, path, width=0.09, height=0.13):
    mesh = UsdGeom.Mesh.Define(stage, path)
    mesh.CreatePointsAttr([
        Gf.Vec3f(-width, 0, 0), Gf.Vec3f(width, 0, 0),
        Gf.Vec3f(width, height * 2, 0), Gf.Vec3f(-width, height * 2, 0),
    ])
    mesh.CreateFaceVertexCountsAttr([4])
    mesh.CreateFaceVertexIndicesAttr([0, 1, 2, 3])
    mesh.CreateExtentAttr([Gf.Vec3f(-width, 0, 0), Gf.Vec3f(width, height * 2, 0)])
    mesh.CreateDoubleSidedAttr(True)
    st = UsdGeom.PrimvarsAPI(mesh).CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, "faceVarying")
    st.Set([Gf.Vec2f(0, 0), Gf.Vec2f(1, 0), Gf.Vec2f(1, 1), Gf.Vec2f(0, 1)])
    return mesh


def build_plant_prototype(stage, path, palette, texture_abs_path):
    """One procedural low bushy broadleaf plant (bean/soy-style, matching
    the reference photo) — short crown + textured leaf-cutout cards
    splaying outward from near the base. Leaf cards only exist once per
    prototype (not per plant instance — the PointInstancer reuses these),
    so the texture and the extra quad geometry cost is paid four times
    total, not 90 times."""
    proto = UsdGeom.Xform.Define(stage, path)

    stem_mat = make_material(stage, path + "/StemMat", palette["stem"])
    leaf_mat = make_leaf_card_material(stage, path + "/LeafMat", texture_abs_path, palette["leaf"])

    crown = UsdGeom.Cylinder.Define(stage, path + "/Crown")
    crown.CreateHeightAttr(0.10)
    crown.CreateRadiusAttr(0.025)
    UsdGeom.Xformable(crown).AddTranslateOp().Set(Gf.Vec3d(0, 0.05, 0))
    UsdShade.MaterialBindingAPI(crown).Bind(stem_mat)

    LEAF_COUNT = 6
    for k in range(LEAF_COUNT):
        angle_deg = k * (360.0 / LEAF_COUNT) + random.uniform(-10, 10)
        angle_rad = math.radians(angle_deg)
        height = random.uniform(0.05, 0.18)
        out_radius = random.uniform(0.02, 0.05)
        tilt_deg = random.uniform(20, 45)

        card = add_leaf_card(stage, f"{path}/Leaf_{k}")
        xf = UsdGeom.Xformable(card)
        xf.AddRotateZOp().Set(tilt_deg)
        xf.AddRotateYOp().Set(angle_deg)
        xf.AddTranslateOp().Set(Gf.Vec3d(
            out_radius * math.cos(angle_rad), height, out_radius * math.sin(angle_rad)
        ))
        UsdShade.MaterialBindingAPI(card).Bind(leaf_mat)

    if "accent" in palette:
        accent_mat = make_material(stage, path + "/AccentMat", palette["accent"])
        bloom = UsdGeom.Sphere.Define(stage, path + "/Bloom")
        bloom.CreateRadiusAttr(0.04)
        UsdGeom.Xformable(bloom).AddTranslateOp().Set(Gf.Vec3d(0, 0.30, 0))
        UsdShade.MaterialBindingAPI(bloom).Bind(accent_mat)

    return proto.GetPrim()


def build_crop_rows(stage, num_rows, row_spacing, plant_spacing, row_length, prototypes):
    """One PointInstancer per row — NOT individual prims per plant. This is
    the load-bearing performance decision: it's what lets you add rows and
    tighten plant spacing without the per-prim overhead that would otherwise
    tank your sim FPS and, downstream, your control loop's tick rate."""
    start_x = -((num_rows - 1) * row_spacing) / 2
    plants_per_row = int(row_length / plant_spacing)

    for r in range(num_rows):
        row_x = start_x + r * row_spacing
        instancer = UsdGeom.PointInstancer.Define(stage, f"/World/CropRows/Row_{r}")
        instancer.CreatePrototypesRel().SetTargets([p.GetPath() for p in prototypes])

        positions, orientations, scales, proto_indices = [], [], [], []
        for p_idx in range(plants_per_row):
            y = -row_length / 2 + p_idx * plant_spacing
            jx = random.uniform(-JITTER_XY, JITTER_XY)
            jy = random.uniform(-JITTER_XY, JITTER_XY)
            positions.append(Gf.Vec3f(row_x + jx, 0.0, y + jy))

            yaw_deg = random.uniform(-JITTER_ROT_DEG, JITTER_ROT_DEG)
            half = math.radians(yaw_deg) / 2.0
            orientations.append(Gf.Quath(math.cos(half), 0.0, math.sin(half), 0.0))

            s = random.uniform(*JITTER_SCALE)
            scales.append(Gf.Vec3f(s, s, s))

            proto_indices.append(random.randint(0, len(prototypes) - 1))

        instancer.CreatePositionsAttr(positions)
        instancer.CreateOrientationsAttr(orientations)
        instancer.CreateScalesAttr(scales)
        instancer.CreateProtoIndicesAttr(proto_indices)

    return plants_per_row


def main():
    texture_path = generate_leaf_texture(os.path.join(TEXTURE_DIR, LEAF_TEXTURE_NAME))
    texture_abs_path = os.path.abspath(texture_path)

    stage = Usd.Stage.CreateNew(OUTPUT_PATH)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)
    stage.SetDefaultPrim(stage.DefinePrim("/World", "Xform"))

    field_width = (NUM_ROWS - 1) * ROW_SPACING + 2 * FIELD_MARGIN

    build_ground(stage, field_width, ROW_LENGTH + 2 * FIELD_MARGIN)
    build_furrows(stage, NUM_ROWS, ROW_SPACING, ROW_LENGTH)

    prototypes = [
        build_plant_prototype(stage, f"/World/Prototypes/{pal['name']}", pal, texture_abs_path)
        for pal in PLANT_PALETTES
    ]

    plants_per_row = build_crop_rows(
        stage, NUM_ROWS, ROW_SPACING, PLANT_SPACING, ROW_LENGTH, prototypes
    )

    stage.GetRootLayer().Save()

    total_plants = NUM_ROWS * plants_per_row
    print(f"Wrote {OUTPUT_PATH}")
    print(f"  Rows: {NUM_ROWS} @ {ROW_SPACING} m spacing (unchanged from Week 4)")
    print(f"  Plants/row: {plants_per_row} @ {PLANT_SPACING} m spacing (was 1.5 m)")
    print(f"  Total instanced plants: {total_plants}")
    print("  Collision: ground only — no per-plant colliders")
    print(f"  Leaf texture: {texture_abs_path} (1 file, referenced by absolute path)")
    print("  NOTE: the texture is referenced by absolute path baked at generation")
    print("  time. This is now a binary .usd (crate format), not text, so you can't")
    print("  gedit-edit the path by hand if you move the file. If you move it to a")
    print("  different machine/folder, just re-run this script from the new location")
    print("  to rebake the correct path.")


if __name__ == "__main__":
    main()
